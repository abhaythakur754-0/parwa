"""PARWA Core — Rust-accelerated hot-path modules.

This package provides Rust-compiled versions of performance-critical
operations: rate limiting, circuit breaking, PII redaction, JWT auth,
and security header generation.

Usage:
    from parwa_core import (
        RateLimiter, CircuitBreaker,
        detect_pii, redact_pii, redact_pii_deterministic,
        create_access_token, verify_access_token,
        generate_security_headers, generate_csrf_nonce, verify_csrf_origin,
        check_rate_limit,
    )
"""

try:
    from parwa_core._parwa_core import (
        RateLimiter,
        CircuitBreaker,
        detect_pii,
        redact_pii,
        redact_pii_deterministic,
        create_access_token,
        verify_access_token,
        generate_security_headers,
        generate_csrf_nonce,
        verify_csrf_origin,
        check_rate_limit,
    )
    _RUST_AVAILABLE = True
except ImportError:
    _RUST_AVAILABLE = False
    RateLimiter = None
    CircuitBreaker = None
    detect_pii = None
    redact_pii = None
    redact_pii_deterministic = None
    create_access_token = None
    verify_access_token = None
    generate_security_headers = None
    generate_csrf_nonce = None
    verify_csrf_origin = None
    check_rate_limit = None


def is_rust_available() -> bool:
    """Check if the Rust native module is loaded."""
    return _RUST_AVAILABLE


__all__ = [
    "RateLimiter",
    "CircuitBreaker",
    "detect_pii",
    "redact_pii",
    "redact_pii_deterministic",
    "create_access_token",
    "verify_access_token",
    "generate_security_headers",
    "generate_csrf_nonce",
    "verify_csrf_origin",
    "check_rate_limit",
    "is_rust_available",
    "_RUST_AVAILABLE",
]
